<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>
        Home page
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Latest compiled and minified CSS -->
    

    <link rel="stylesheet" href="/css/bootstrap.css" >

</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="bg-info">
                Всего овечек: <?php echo e($all); ?>

            </p>
            <p class="bg-success">Живых овечек: <?php echo e($live); ?></p>
            <p class="bg-danger">Усыпленных овечек: <?php echo e($sleep); ?></p>
            <p class="bg-primary">Самый населеный загон №: <?php echo e($max->paddock); ?>. Количество овец в загоне: <?php echo e($max->total); ?></p>
            <p class="bg-primary">Самый маленький загон №: <?php echo e($min->paddock); ?>. Количество овец в загоне: <?php echo e($min->total); ?></p>
        </div>
    </div>
</div>

<style>
    p{
        padding: 2em;
    }
</style>
</body>
</html>

<?php
//var_dump($all, $min, $max, $live, $sleep);